<?php
	/**
	 * Object represents table 'telefonos'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-02-11 11:07	 
	 */
	class Telefono{
		
		var $idTelefono;
		var $idCliente;
		var $tipo;
		var $telefono;
		
	}
?>
<?php
	/**
	 * Object represents table 'cliente'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2017-02-11 11:07	 
	 */
	class Cliente{
		
		var $id;
		var $nombres;
		var $ciudad;
		var $sexo;
		var $fechaNacimiento;
		
	}
?>
<?php
/**
 * Class that operate on table 'cliente'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2017-02-11 11:07
 */
class ClienteMySqlExtDAO extends ClienteMySqlDAO{

	
}
?>
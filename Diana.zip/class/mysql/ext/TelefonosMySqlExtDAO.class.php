<?php
/**
 * Class that operate on table 'telefonos'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2017-02-11 11:07
 */
class TelefonosMySqlExtDAO extends TelefonosMySqlDAO{

	
}
?>